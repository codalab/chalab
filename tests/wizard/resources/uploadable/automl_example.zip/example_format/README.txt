Sample data for AutoML challenge
Isabelle Guyon, March 2015

=======

Contents:

- mydataset.data: a space delimited file with samples in lines and features in columns.

- mydataset_sample.name: the names of the samples (The number of lines in this file = the number of lines of sample.data. This file can be used to document the nature of the samples and the recording conditions to avoid biasing the data split.)

- mydataset_feat.name: the names of the features (The number of lines in this file = the number of columns of sample.data. This file can be used to document the features. It will eventually be used to suppress some features to avoid "leakage" problems, i.e. providing the solution in the features.)

- mydataset.solution: a space delimited file with samples in lines and target values (to be predicted) in columns (in the example there is a single target, so a single column.)

- mydataset_label.name: the name(s) of the columns of mydataset.solution.

- mydataset_info.m: the meta data of the dataset.


For simplicity, we do not split the data in this example. However, the challenge participants are given data after splitting into training, validation and test set. They get:
mydataset_train.data
mydataset_train.solution
mydataset_valid.data
mydataset_test.data

The organizers keep the files that must be predicted:
mydataset_valid.solution
mydataset_test.solution
mydataset_feat.name
The organizers also keep the information files:
mydataset_sample.name
mydataset_label.name
mydataset_info.m (the participants get a subset of the information only, e.g. the nature of the features, the type of task, etc.)

Important: In order to make a data split that is not biased it is important to document the sample source in mydataset_sample.name. For instance, if several samples are repeated measurements performed in the same conditions, we may (or may not) want to split them accross training, validation, and test sets (depending on the nature of the prediction task).





