% Example of info meta data for sample data

% General public information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
info.public.usage='AutoML challenge 2015';                      % You can leave this "as is"
info.public.name='mydataset';                                   % Fill out the name of the dataset
info.public.task='binary.classification';                       % A choice of 'binary.classification',
                                                                % 'multiclass.classification',
                                                                % 'multilabel.classification',
                                                                % 'categorical.regression', 'regression'
info.public.target_type='Binary';                               % A choice of 'Numerical', 'Categorical',
                                                                % or 'Binary' (no mixing)
info.public.feat_type='Numerical';                              % A choice of 'Numerical', 'Categorical',
                                                                % 'Binary', or 'Mixed'
info.public.metric='auc_metric'; % You can leave "as is"

% General private information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
info.private.title='Sample dataset';
info.private.keywords='pattern.recognition';                    % Any useful keyword(s)
info.private.authors='TBA';                                     % Original authors
info.private.resource_url='TBA';                                % URL of the web page of the original data
info.private.contact_name='TBA';                                % Donnor name
info.private.contact_url='http://xxxx';                         % Web site of donnor (or donnor institution)
info.private.license='unknown';                                 % Give name or URL or license terms
info.private.date_created=date;                                 % Leave this "as is"
info.private.past_usage='TBA';                                  % Data used before (e.g. in other challenges)?
info.private.description='TBA';                                 % Describe the data and task(s)
info.private.preparation='TBA';                                 % Data collection and preprocessing
info.private.representation='TBA';                              % Describe the type of features